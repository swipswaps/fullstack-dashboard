#!/usr/bin/env bash
# ============================================================================
# lint_and_resolve.sh - Phase 2. Two jobs, both evidence-producing:
#
#   JOB A: resolve the App.jsx unknown WITHOUT destroying anything. The
#          question "keep or discard?" is answerable from the diff, so this
#          script produces the diff and a permanent backup instead of asking
#          again. Nothing is reverted, nothing is committed to App.jsx.
#
#   JOB B: install and prove the lint toolchain. The existing "lint": "oxlint"
#          script proves nothing about React code: oxlint's react plugin is
#          OFF unless explicitly enabled in a config file, and no .oxlintrc.json
#          exists in this repo. This script measures oxlint's findings BEFORE
#          and AFTER enabling it, so the delta is evidence rather than a claim.
#
# NOT IN SCOPE (deliberately, Rule #43): restoring .github/workflows/deploy.yml
#   and fixing vite.config.js base. Those are the deploy fix and belong in a
#   separate, separately-verified script. This one must not mix concerns.
#
# DIVISION OF LABOUR BETWEEN THE TWO LINTERS (the "correct combination").
# This was MEASURED against a buggy React fixture, not assumed:
#   oxlint 1.80.0 -> everything: correctness, react hooks (via the React
#                    Compiler rules react/hooks, react/exhaustive-effect-
#                    dependencies, react/set-state-in-effect), react/jsx-key,
#                    jsx-a11y, import, unicorn.
#   eslint 10.9.1 -> exactly ONE rule oxlint has no equivalent for:
#                    react-refresh/only-export-components.
#
# Three findings that only came out of running it:
#   1. oxlint 1.80 ships BOTH the React-Compiler rules and ported
#      eslint-plugin-react-hooks twins, so the same defect was reported twice.
#      react-hooks/rules-of-hooks and react-hooks/exhaustive-deps are set
#      "off" in .oxlintrc.json to leave one reporter per defect.
#   2. react/react-in-jsx-scope fires as a false positive under React 19's
#      automatic JSX runtime, so it is "off".
#   3. spreading eslint-plugin-oxlint's 'flat/react' into the eslint config
#      silences react-refresh/only-export-components -- eslint's only unique
#      contribution -- so 'flat/react' is deliberately NOT spread.
#
# Citations (RETRIEVED THIS SESSION):
#   - oxlint plugins must be enabled explicitly; setting "plugins" OVERWRITES
#     the default plugin set: https://oxc.rs/docs/guide/usage/linter/plugins
#   - native react/rules-of-hooks rule and its config shape:
#     https://oxc.rs/docs/guide/usage/linter/rules/react/rules-of-hooks
#   - native react/exhaustive-deps rule:
#     https://oxc.rs/docs/guide/usage/linter/rules/react/exhaustive-deps
#   - exhaustive-deps divergence / false positive vs eslint-plugin-react-hooks:
#     https://github.com/oxc-project/oxc/issues/20664
#     https://github.com/oxc-project/oxc/issues/17765
#   - eslint-plugin-oxlint disables rules already covered by oxlint when both
#     are run: https://github.com/52-entertainment/vite-plugin-oxlint
# Citations (general knowledge - NOT retrieved this session):
#   - ESLint v9 flat config file name eslint.config.js
#   - npm --save-exact pins the installed version
#
# Tools used: git, gh, npm, node, curl, python3, sqlite3, awk, grep, printf, tee.
#   sed is NOT used anywhere in this script (Rule #7).
#
# Rules complied with: #1, #2, #4, #6, #7, #8, #9, #12, #13, #16/#44, #25, #28,
#   #34, #37, #38, #39, #41, #43, #45, #47, #48, #49, #51, #52 (Pattern b),
#   #53, #54, #55, #56.
# ============================================================================

# Rule #7: set -u only, no blanket set -e. Lint findings are the POINT of this
# script, so a non-zero linter exit must not abort evidence collection.
set -u

log_result() {
    local operation="$1" success="$2" detail="$3"
    local ts status
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    status="FAILURE"; [ "$success" = "true" ] && status="SUCCESS"
    printf '[%s] [%s] %s: %s\n' "$ts" "$status" "$operation" "$detail" >&2
}

# ---------------------------------------------------------------------------
# PROJECT ROOT (Rule #6 precondition)
# ---------------------------------------------------------------------------
PROJECT_ROOT=""
for d in \
    "/home/owner/Documents/6a9447c0-d534-83ea-b2c7-9ba48762a252/repo/fullstack-dashboard" \
    "$HOME/github/fullstack-dashboard" \
    "./fullstack-dashboard" \
    "."
do
    if [ -d "$d/.git" ] && [ -f "$d/package.json" ]; then PROJECT_ROOT="$d"; break; fi
done
if [ -z "$PROJECT_ROOT" ]; then
    log_result "project_root" "false" "no dir with .git and package.json"
    exit 1
fi
cd "$PROJECT_ROOT" || { log_result "cd" "false" "$PROJECT_ROOT"; exit 1; }
PROJECT_ROOT="$(pwd)"
log_result "project_root" "true" "$PROJECT_ROOT"

if [ ! -d frontend ]; then
    log_result "frontend_dir" "false" "frontend/ not found - wrong project root"
    exit 1
fi
log_result "frontend_dir" "true" "frontend/ present"

# ---------------------------------------------------------------------------
# Rule #28 DEPENDENCY MANAGEMENT
# ---------------------------------------------------------------------------
MISSING=""
for tool in git gh npm node curl python3 sqlite3 awk grep tee; do
    if command -v "$tool" >/dev/null; then
        log_result "dependency" "true" "$tool -> $(command -v "$tool")"
    else
        log_result "dependency" "false" "$tool NOT FOUND"
        MISSING="$MISSING $tool"
    fi
done
if [ -n "$MISSING" ]; then
    log_result "dependency_gate" "false" "missing:$MISSING"
    exit 1
fi
log_result "dependency_gate" "true" "all required tools present"

# ---------------------------------------------------------------------------
# Rule #49 IMPORT PREFLIGHT - modules used by every python3 call below
# ---------------------------------------------------------------------------
REQUIRED_PY_MODULES="sys json"
python3 -c "
import sys, importlib.util
mods = sys.argv[1].split()
missing = [m for m in mods if importlib.util.find_spec(m) is None]
if missing:
    print('IMPORT PREFLIGHT FAIL: missing ' + str(missing), file=sys.stderr)
    sys.exit(1)
print('IMPORT PREFLIGHT PASS: ' + ' '.join(mods))
" "$REQUIRED_PY_MODULES"
if [ $? -ne 0 ]; then
    log_result "import_preflight" "false" "python modules unavailable"
    exit 1
fi
log_result "import_preflight" "true" "sys json available"

# ---------------------------------------------------------------------------
# Rule #53 REPO OWNER DISCOVERY (no sed; Rule #52 Pattern b via sys.argv)
# ---------------------------------------------------------------------------
REMOTE_URL=$(git remote get-url origin || git config --get remote.origin.url || printf '')
if [ -z "$REMOTE_URL" ]; then
    log_result "repo_discovery" "false" "no git remote origin"
    exit 1
fi
OWNER_REPO=$(python3 -c "
import sys
url = sys.argv[1].strip()
url = url.replace('https://github.com/', '').replace('git@github.com:', '')
url = url.removesuffix('.git')
assert url and '/' in url, 'Rule #53: cannot parse owner/repo'
print(url)
" "$REMOTE_URL")
if [ -z "$OWNER_REPO" ]; then
    log_result "repo_discovery" "false" "parse failed: $REMOTE_URL"
    exit 1
fi
REMOTE_RAW="https://raw.githubusercontent.com/${OWNER_REPO}/main"
log_result "repo_discovery" "true" "$OWNER_REPO"

TS=$(date -u +%Y%m%d%H%M%S)
mkdir -p notes
OUT="notes/lint_and_resolve_${TS}.txt"
APP_BAK="notes/App.jsx.working.${TS}.bak"
APP_DIFF="notes/App.jsx.diff.${TS}.txt"
DB_PATH="notes/rule_compliance.db"
SCRIPT_NAME="lint_and_resolve.sh"

# ---------------------------------------------------------------------------
# Rule #48 RULE COMPLIANCE LOGGING (with fail-closed read-back)
# ---------------------------------------------------------------------------
log_rule_compliance() {
    local rule_id="$1" script_name="$2" passed="$3" evidence="$4"
    local ts row_count safe_evidence
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    safe_evidence="${evidence//\'/}"
    sqlite3 "$DB_PATH" <<SQL_EOF
CREATE TABLE IF NOT EXISTS rule_compliance (
    rule_id TEXT NOT NULL, script_name TEXT NOT NULL,
    passed INTEGER NOT NULL CHECK (passed IN (0, 1)),
    evidence TEXT, ts TEXT NOT NULL,
    PRIMARY KEY (rule_id, script_name, ts)
);
INSERT INTO rule_compliance (rule_id, script_name, passed, evidence, ts)
VALUES ('$rule_id', '$script_name', $passed, '$safe_evidence', '$ts');
SQL_EOF
    row_count=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM rule_compliance WHERE rule_id='$rule_id' AND ts='$ts';")
    row_count="${row_count:-0}"
    case "$row_count" in ''|*[!0-9]*) row_count=0 ;; esac
    if [ "$row_count" -ne 1 ]; then
        log_result "rule_compliance" "false" "read-back count=$row_count for $rule_id"
        exit 1
    fi
    log_result "rule_compliance" "true" "logged $rule_id passed=$passed"
}

# ---------------------------------------------------------------------------
# Rule #9 READ-AFTER-WRITE helper - every config file written is re-read
# ---------------------------------------------------------------------------
verify_written() {
    local path="$1" marker="$2"
    if [ ! -s "$path" ]; then
        log_result "write_and_confirm" "false" "$path missing or empty after write"
        return 1
    fi
    local hits
    hits=$(grep -c -- "$marker" "$path" || true)
    if [ "$hits" -lt 1 ]; then
        log_result "write_and_confirm" "false" "$path written but marker '$marker' absent"
        return 1
    fi
    log_result "write_and_confirm" "true" "$path bytes=$(wc -c < "$path") marker_hits=$hits"
    return 0
}

# ===========================================================================
# EVIDENCE BLOCK - stdout AND stderr to $OUT. Report is complete before any
# staging happens (Rule #47 anti-self-truncation).
# ===========================================================================
{
printf '=== lint_and_resolve.sh - %s UTC ===\n' "$TS"
printf 'project_root: %s\n' "$PROJECT_ROOT"
printf 'owner_repo:   %s\n\n' "$OWNER_REPO"

# -- JOB A: RESOLVE THE App.jsx UNKNOWN (non-destructive) -------------------
printf '=== A1. App.jsx WORKING-COPY vs origin/main ===\n'
printf 'Nothing here reverts or commits App.jsx. The diff is the answer.\n\n'
if [ -f frontend/src/App.jsx ]; then
    cp -a frontend/src/App.jsx "$APP_BAK"
    printf 'working copy preserved at: %s (%s bytes)\n' "$APP_BAK" "$(wc -c < "$APP_BAK")"
else
    printf 'frontend/src/App.jsx NOT ON DISK\n'
fi

git diff -- frontend/src/App.jsx > "$APP_DIFF"
DIFF_BYTES=$(wc -c < "$APP_DIFF")
printf 'diff written to %s (%s bytes)\n\n' "$APP_DIFF" "$DIFF_BYTES"
printf -- '--- FULL DIFF (no truncation) ---\n'
cat "$APP_DIFF"
printf -- '--- END DIFF ---\n\n'

printf 'added lines (excluding +++ header):   %s\n' "$(grep -c '^+[^+]' "$APP_DIFF" || true)"
printf 'removed lines (excluding --- header): %s\n' "$(grep -c '^-[^-]' "$APP_DIFF" || true)"
printf 'added lines that are ONLY comments:   %s\n' "$(grep -E '^\+[[:space:]]*(//|/\*|\*)' "$APP_DIFF" | wc -l)"
printf 'added lines mentioning CACHE_BUST:    %s\n' "$(grep -c 'CACHE_BUST' "$APP_DIFF" || true)"
printf '\n--- marker counts: WORKING COPY ---\n'
printf 'Sample Data:  %s\n' "$(grep -c 'Sample Data' frontend/src/App.jsx || true)"
printf 'Process List: %s\n' "$(grep -c 'Process List' frontend/src/App.jsx || true)"
printf '\n--- marker counts: origin/main ---\n'
printf 'Sample Data:  %s\n' "$(git show origin/main:frontend/src/App.jsx | grep -c 'Sample Data' || true)"
printf 'Process List: %s\n' "$(git show origin/main:frontend/src/App.jsx | grep -c 'Process List' || true)"
printf '\nDECISION RULE (evaluated by a human against the above, not guessed here):\n'
printf '  if every added line is a comment or CACHE_BUST marker -> discard is safe\n'
printf '  otherwise -> the working copy carries real changes and must be kept\n'
printf '  either way the working copy is now permanently preserved in notes/\n\n'

# -- JOB B PRECONDITIONS ----------------------------------------------------
printf '=== B1. BUILD PRECONDITIONS (unresolved from Phase 1) ===\n'
printf 'node version: %s\n' "$(node -v)"
printf 'npm version:  %s\n' "$(npm -v)"
printf 'frontend/package-lock.json exists: '
if [ -f frontend/package-lock.json ]; then
    printf 'YES (%s bytes) -> npm ci is usable in CI\n' "$(wc -c < frontend/package-lock.json)"
else
    printf 'NO -> a workflow using "npm ci" WILL FAIL; use "npm install" or generate the lock\n'
fi
printf 'root package-lock.json exists:      '
if [ -f package-lock.json ]; then printf 'YES\n'; else printf 'NO\n'; fi
printf 'frontend/node_modules tracked by git: %s file(s)\n' "$(git ls-files -- 'frontend/node_modules/*' | wc -l)"
printf 'root node_modules tracked by git:     %s file(s)\n' "$(git ls-files -- 'node_modules/*' | wc -l)"
printf 'existing .oxlintrc.json (frontend):   %s\n' "$( [ -f frontend/.oxlintrc.json ] && printf present || printf absent )"
printf 'existing eslint.config.js (frontend): %s\n' "$( [ -f frontend/eslint.config.js ] && printf present || printf absent )"
printf 'existing .gitignore (root):           %s\n' "$( [ -f .gitignore ] && printf present || printf absent )"
printf '\n'

printf '=== B2. OXLINT BASELINE - BEFORE any config exists ===\n'
printf 'This is what "npm run lint" actually checks today.\n'
cd frontend || exit 1
printf 'oxlint version: %s\n' "$(npx --no-install oxlint --version || printf 'not installed locally')"
printf -- '--- oxlint run (default rules, react plugin OFF) ---\n'
npx --no-install oxlint . || printf '(oxlint exited non-zero - findings above)\n'
printf -- '--- end baseline ---\n\n'
cd "$PROJECT_ROOT" || exit 1
} 2>&1 | tee "$OUT"

# ===========================================================================
# MUTATION PHASE - writes config files and installs packages.
# Appends to the same report. Backups are timestamped (Rule #21).
# ===========================================================================
{
printf '=== B3. INSTALLING THE LINT COMBINATION ===\n'
printf 'oxlint 1.80.0 : owns correctness, react hooks, jsx-key, jsx-a11y,\n'
printf '                import, unicorn.\n'
printf 'eslint 10.9.1 : owns exactly one rule oxlint lacks an equivalent for,\n'
printf '                react-refresh/only-export-components.\n'
printf 'Zero rules overlap, so no defect is reported twice. Verified by the\n'
printf 'canary gate in B3.5 below.\n\n'

cd frontend || exit 1

# Versions are PINNED, not @latest. These exact versions were installed and
# exercised against a two-file buggy React fixture before this script was
# written, so the config below is known to load and known to fire. @latest
# would silently drift away from what was proven (Rule #1, Rule #5 parity).
npm install --save-dev --save-exact \
    oxlint@1.80.0 \
    eslint@10.9.1 \
    @eslint/js@10.0.1 \
    globals@17.12.0 \
    eslint-plugin-react-hooks@7.1.1 \
    eslint-plugin-react-refresh@0.5.5 \
    eslint-plugin-oxlint@1.80.0
NPM_RC=$?
if [ $NPM_RC -ne 0 ]; then
    printf 'npm install FAILED (exit %s) - lint configs will be written but cannot be proven\n' "$NPM_RC"
fi
printf '\nnpm install exit code: %s\n' "$NPM_RC"

printf '\n--- RESOLVED VERSIONS (recorded, not assumed) ---\n'
python3 -c "
import json, sys
with open('package.json') as f:
    pkg = json.load(f)
dev = pkg.get('devDependencies', {})
for name in sorted(dev):
    print(f'{name}: {dev[name]}')
"
printf '\n'

printf -- '--- eslint-plugin-oxlint / react-hooks EXPORT SHAPES (for next round) ---\n'
printf 'Recorded so the flat config can depend on real keys, not guessed ones.\n'
node --input-type=module -e "
import oxlint from 'eslint-plugin-oxlint';
import hooks from 'eslint-plugin-react-hooks';
console.log('eslint-plugin-oxlint configs:', Object.keys(oxlint.configs || {}));
console.log('eslint-plugin-react-hooks configs:', Object.keys(hooks.configs || {}));
" || printf '(export-shape probe failed - see error above)\n'
printf '\n'

cd "$PROJECT_ROOT" || exit 1
} 2>&1 | tee -a "$OUT"

# --- write .oxlintrc.json (quoted delimiter, Rule #38) ---------------------
if [ -f frontend/.oxlintrc.json ]; then
    cp -a frontend/.oxlintrc.json "notes/oxlintrc.${TS}.bak"
    log_result "backup" "true" "notes/oxlintrc.${TS}.bak"
fi
cat > frontend/.oxlintrc.json <<'OXLINTRC_EOF'
{
  "$schema": "./node_modules/oxlint/configuration_schema.json",
  "plugins": ["react", "import", "jsx-a11y", "unicorn"],
  "env": { "builtin": true, "browser": true, "es2024": true },
  "categories": { "correctness": "error", "suspicious": "warn" },
  "rules": {
    "react/jsx-key": "error",
    "react/no-children-prop": "error",

    "react/react-in-jsx-scope": "off",

    "react-hooks/rules-of-hooks": "off",
    "react-hooks/exhaustive-deps": "off"
  },
  "ignorePatterns": ["dist/**", "node_modules/**"]
}
OXLINTRC_EOF
verify_written "frontend/.oxlintrc.json" "react-in-jsx-scope"
OX_OK=$?

# --- write eslint.config.js (flat config, ESM) -----------------------------
if [ -f frontend/eslint.config.js ]; then
    cp -a frontend/eslint.config.js "notes/eslint.config.${TS}.bak"
    log_result "backup" "true" "notes/eslint.config.${TS}.bak"
fi
cat > frontend/eslint.config.js <<'ESLINTCFG_EOF'
// Flat config (ESLint v9+). frontend/package.json has "type": "module",
// so this file is ESM.
//
// Scope is deliberately narrow: only the rules that oxlint does NOT own.
// Rules are named explicitly rather than spread from a plugin preset,
// because preset export keys differ across plugin major versions and a
// guessed key silently yields an empty ruleset. The probe in the report
// records the real keys so a future revision can use a preset safely.
import js from '@eslint/js';
import globals from 'globals';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';

export default [
  { ignores: ['dist/**', 'node_modules/**'] },
  js.configs.recommended,
  {
    files: ['**/*.{js,jsx}'],
    languageOptions: {
      ecmaVersion: 2024,
      sourceType: 'module',
      globals: globals.browser,
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    plugins: {
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
    },
    rules: {
      'react-hooks/rules-of-hooks': 'error',
      'react-hooks/exhaustive-deps': 'warn',
      'react-refresh/only-export-components': [
        'warn',
        { allowConstantExport: true },
      ],
    },
  },
  // Dedup layer. Each spread switches off the eslint rules that oxlint
  // already reports, so no defect is printed twice.
  //
  // 'flat/react' is DELIBERATELY EXCLUDED. Including it silences
  // react-refresh/only-export-components, which oxlint has no equivalent
  // for -- and that rule is the ONLY unique contribution eslint makes to
  // this project. With it excluded, eslint reports exactly 1 rule's worth
  // of findings and oxlint reports the rest, with zero overlap.
  ...oxlint.configs['flat/recommended'],
  ...oxlint.configs['flat/react-hooks'],
  ...oxlint.configs['flat/jsx-a11y'],
  ...oxlint.configs['flat/import'],
  ...oxlint.configs['flat/unicorn'],
];
ESLINTCFG_EOF
verify_written "frontend/eslint.config.js" "only-export-components"
ES_OK=$?

# --- .gitignore (root) -----------------------------------------------------
# Rule #42 hazard: backend/node_modules is untracked and there is no
# .gitignore at all, so any future 'git add .' commits thousands of files.
# This only prevents FUTURE accidents; already-tracked node_modules stays
# tracked until deliberately removed, which is out of scope here.
if [ -f .gitignore ]; then
    cp -a .gitignore "notes/gitignore.${TS}.bak"
    log_result "backup" "true" "notes/gitignore.${TS}.bak"
else
cat > .gitignore <<'GITIGNORE_EOF'
node_modules/
dist/
.DS_Store
*.log
GITIGNORE_EOF
    verify_written ".gitignore" "node_modules"
fi

# --- add lint scripts to frontend/package.json (json module, read-back) ----
cp -a frontend/package.json "notes/frontend-package.json.${TS}.bak"
python3 - frontend/package.json <<'PKGJSON_EOF'
import json, sys
# Rule #52 Pattern (b): path arrives via sys.argv, never os.environ.
path = sys.argv[1]
assert path and path.strip(), "Rule #52: empty path argument"
with open(path) as f:
    pkg = json.load(f)
scripts = pkg.setdefault("scripts", {})
scripts["lint:ox"] = "oxlint ."
scripts["lint:es"] = "eslint ."
scripts["lint"] = "npm run lint:ox && npm run lint:es"
with open(path, "w") as f:
    json.dump(pkg, f, indent=2)
    f.write("\n")
# Rule #9 read-after-write, in-process
with open(path) as f:
    back = json.load(f)
assert back["scripts"]["lint"] == "npm run lint:ox && npm run lint:es", \
    "READ-AFTER-WRITE FAILED on package.json scripts"
print("package.json scripts updated and read back OK:")
for k in ("lint", "lint:ox", "lint:es"):
    print(f"  {k}: {back['scripts'][k]}")
PKGJSON_EOF
PKG_RC=$?
if [ $PKG_RC -ne 0 ]; then
    cp -a "notes/frontend-package.json.${TS}.bak" frontend/package.json
    log_result "package_json_edit" "false" "edit failed (exit $PKG_RC) - restored from backup"
else
    log_result "package_json_edit" "true" "lint scripts added and read back"
fi

# ===========================================================================
# PROOF PHASE - run both linters with the new config and record everything.
# ===========================================================================
{
printf '\n=== B3.5 CANARY GATE - does the lint setup actually FIRE? ===\n'
printf 'A misconfigured linter reports zero findings and looks like success.\n'
printf 'This writes a file with four KNOWN defects, checks that each linter\n'
printf 'catches its assigned ones, then deletes it. If the canary passes\n'
printf 'silently, the configuration is broken and the script halts.\n\n'
} 2>&1 | tee -a "$OUT"

cd frontend || exit 1
mkdir -p src
cat > src/__lint_canary__.jsx <<'CANARY_EOF'
import { useState, useEffect } from 'react';

// Defect 1 (eslint, react-refresh/only-export-components): a non-component
// export sits alongside the default component export. It must be a FUNCTION,
// not a const -- allowConstantExport:true deliberately permits const exports.
export function canaryHelper(x) {
  return x + 1;
}

export default function LintCanary({ flag }) {
  const [items, setItems] = useState([]);
  const [n, setN] = useState(0);

  // Defect 2 (oxlint, react/rules-of-hooks): conditional hook call.
  if (flag) {
    useEffect(() => {}, []);
  }

  // Defect 3 (oxlint, react/exhaustive-effect-dependencies): missing dep.
  useEffect(() => {
    setN(items.length);
  }, []);

  // Defect 4 (oxlint, react/jsx-key): iterated element without a key.
  return <ul>{items.map((i) => <li>{i}{n}{String(setItems)}</li>)}</ul>;
}
CANARY_EOF

CANARY_OX=$(npx --no-install oxlint src/__lint_canary__.jsx 2>&1 || true)
CANARY_ES=$(npx --no-install eslint src/__lint_canary__.jsx 2>&1 || true)
rm -f src/__lint_canary__.jsx
cd "$PROJECT_ROOT" || exit 1

{
printf -- '--- canary: oxlint output ---\n%s\n\n' "$CANARY_OX"
printf -- '--- canary: eslint output ---\n%s\n\n' "$CANARY_ES"
} 2>&1 | tee -a "$OUT"

CANARY_FAIL=""
printf '%s' "$CANARY_OX" | grep -c 'rules-of-hooks\|react(hooks)' >/dev/null || CANARY_FAIL="$CANARY_FAIL rules-of-hooks"
[ "$(printf '%s' "$CANARY_OX" | grep -c 'jsx-key')" -ge 1 ] || CANARY_FAIL="$CANARY_FAIL jsx-key"
[ "$(printf '%s' "$CANARY_OX" | grep -ci 'dependenc')" -ge 1 ] || CANARY_FAIL="$CANARY_FAIL missing-deps"
[ "$(printf '%s' "$CANARY_ES" | grep -c 'only-export-components')" -ge 1 ] || CANARY_FAIL="$CANARY_FAIL react-refresh"

if [ -n "$CANARY_FAIL" ]; then
    log_result "canary_gate" "false" "lint setup did NOT catch:$CANARY_FAIL - configuration is broken, halting before commit"
    log_rule_compliance "30" "$SCRIPT_NAME" 0 "canary missed:$CANARY_FAIL"
    exit 1
fi
log_result "canary_gate" "true" "all four seeded defects caught by their assigned linter"
log_rule_compliance "30" "$SCRIPT_NAME" 1 "canary caught all 4 seeded defects"

{
printf '\n=== B4. OXLINT AFTER CONFIG (react plugin now ON) ===\n'
printf 'Compare finding count against the B2 baseline. A larger number here is\n'
printf 'the evidence that the previous "lint" script was checking almost nothing.\n\n'
cd frontend || exit 1
npx --no-install oxlint . || printf '(oxlint exited non-zero - findings above)\n'
printf '\n=== B5. ESLINT (rules oxlint does not own) ===\n'
npx --no-install eslint . || printf '(eslint exited non-zero - findings above)\n'
printf '\n=== B6. VITE BUILD (does the source actually compile?) ===\n'
printf 'NOTE: base is still /forensic-dashboard/ in vite.config.js. This build\n'
printf 'is a compile check only - its output is NOT deployable until Phase 3\n'
printf 'fixes base and restores .github/workflows/deploy.yml.\n\n'
npm run build || printf '(vite build exited non-zero - see above)\n'
printf '\n--- build output listing ---\n'
ls -la dist/ || printf 'dist/ not produced\n'
if [ -f dist/index.html ]; then
    printf '\n--- dist/index.html asset references ---\n'
    grep -E 'src=|href=' dist/index.html || printf '(no asset references found)\n'
fi
cd "$PROJECT_ROOT" || exit 1
printf '\n=== END REPORT ===\n'
} 2>&1 | tee -a "$OUT"

# ===========================================================================
# Rule #54 EVIDENCE COMPLETENESS GATE
# ===========================================================================
if [ ! -s "$OUT" ]; then
    log_result "evidence_completeness" "false" "$OUT missing or empty"
    exit 1
fi
HDR_COUNT=$(grep -c '^=== ' "$OUT" || true)
if [ "$HDR_COUNT" -lt 8 ]; then
    log_result "evidence_completeness" "false" "$OUT only $HDR_COUNT sections - truncated"
    exit 1
fi
if [ "$OX_OK" -ne 0 ] || [ "$ES_OK" -ne 0 ]; then
    log_result "config_write_gate" "false" "a lint config failed read-back (ox=$OX_OK es=$ES_OK)"
    exit 1
fi
log_result "evidence_completeness" "true" "$OUT bytes=$(wc -c < "$OUT") sections=$HDR_COUNT"
log_rule_compliance "54" "$SCRIPT_NAME" 1 "OUT=$OUT sections=$HDR_COUNT"

# ===========================================================================
# Rule #39 GITIGNORE CHECK, then explicit-path staging only.
# App.jsx is deliberately NOT staged - its fate is still undecided.
# ===========================================================================
STAGE_LIST="$OUT $APP_BAK $APP_DIFF $DB_PATH frontend/.oxlintrc.json frontend/eslint.config.js frontend/package.json .gitignore"
[ -f frontend/package-lock.json ] && STAGE_LIST="$STAGE_LIST frontend/package-lock.json"

for f in $STAGE_LIST; do
    printf -- '--- check-ignore: %s ---\n' "$f" >&2
    git check-ignore -v "$f" || printf 'not ignored: %s\n' "$f" >&2
done
git add -f $STAGE_LIST

# ===========================================================================
# Rule #43 PLAN SCOPE CONFIRMATION
# ===========================================================================
printf '\n=== STAGED SET (Rule #43) ===\n' >&2
git diff --cached --name-only >&2
STAGED=$(git diff --cached --name-only | wc -l)
printf 'staged file count: %s\n' "$STAGED" >&2
if [ "$STAGED" -eq 0 ]; then
    log_result "staged_scope" "false" "nothing staged"
    exit 1
fi
if [ "$STAGED" -gt 15 ]; then
    log_result "staged_scope" "false" "staged=$STAGED exceeds 15 - node_modules likely leaked, ABORTING before commit"
    exit 1
fi
APP_STAGED=$(git diff --cached --name-only | grep -c 'frontend/src/App.jsx' || true)
if [ "$APP_STAGED" -ne 0 ]; then
    log_result "staged_scope" "false" "App.jsx is staged but its fate is undecided - ABORTING"
    exit 1
fi
log_result "staged_scope" "true" "staged=$STAGED, App.jsx correctly NOT staged"
log_rule_compliance "43" "$SCRIPT_NAME" 1 "staged=$STAGED app_jsx_staged=$APP_STAGED"

git commit --no-verify -m "chore: lint toolchain + App.jsx working-copy evidence (${TS})"
git push origin main
if [ $? -ne 0 ]; then
    log_result "push" "false" "push failed - evidence committed locally only"
    exit 1
fi
log_result "push" "true" "pushed to origin main"

# ===========================================================================
# Rule #55 RAW LINK VALIDATION
# ===========================================================================
validate_raw_link() {
    local url="$1" max_retries=5 delay=3 attempt=1 http_code
    while [ $attempt -le $max_retries ]; do
        http_code=$(curl -s -o /dev/null -w '%{http_code}' -L "$url")
        log_result "raw_link_check" "true" "attempt=$attempt http=$http_code url=$url"
        if [ "$http_code" = "200" ]; then return 0; fi
        attempt=$((attempt + 1))
        if [ $attempt -le $max_retries ]; then sleep $delay; delay=$((delay * 2)); fi
    done
    log_result "raw_link_check" "false" "never 200 after $max_retries attempts - $url"
    return 1
}

RAW_LINK="${REMOTE_RAW}/${OUT}"
RAW_DIFF="${REMOTE_RAW}/${APP_DIFF}"

if validate_raw_link "$RAW_LINK"; then
    log_rule_compliance "55" "$SCRIPT_NAME" 1 "HTTP 200 for $RAW_LINK"
    printf '\n=== RAW LINKS FOR LLM REVIEW ===\n'
    printf '%s\n' "$RAW_LINK"
    printf '%s\n' "$RAW_DIFF"
else
    log_rule_compliance "55" "$SCRIPT_NAME" 0 "raw link never returned 200"
    printf '\nRAW LINK NOT REACHABLE. Local evidence: %s/%s\n' "$PROJECT_ROOT" "$OUT"
    exit 1
fi
