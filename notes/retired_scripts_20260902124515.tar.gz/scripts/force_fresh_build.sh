#!/usr/bin/env bash
#
# force_fresh_build.sh
#
# Forces a fresh build by:
#   1. Writing the correct App.jsx (full forensic UI)
#   2. Updating the GitHub Actions workflow with a timestamped cache key
#   3. Committing and pushing to trigger a fresh build
#   4. Waiting for deployment
#   5. Opening with cache-bust parameter
#
# No sed, only cat heredocs.

set -u

# Find the project
PROJECT_DIR=""
for d in "$HOME/github/fullstack-dashboard" "$HOME/Documents/6a9447c0-d534-83ea-b2c7-9ba48762a252/repo/fullstack-dashboard" "./fullstack-dashboard" "../fullstack-dashboard"; do
    if [[ -d "$d" ]] && [[ -f "$d/package.json" ]]; then
        PROJECT_DIR="$d"
        break
    fi
done

if [[ -z "$PROJECT_DIR" ]]; then
    echo "ERROR: fullstack-dashboard not found."
    exit 1
fi

cd "$PROJECT_DIR" || exit 1
echo "--- Project found at: $(pwd) ---"

TIMESTAMP=$(date +%s)

# 1. Ensure App.jsx has the full forensic UI (overwrite)
echo "--- Overwriting App.jsx with full forensic UI ---"
cat > frontend/src/App.jsx <<'APP_JSX'
import React, { useState, useEffect } from 'react';
import './App.css';

const API_BASE = import.meta.env.PROD ? 'http://localhost:3001/api' : '/api';

function App() {
  const [backendStatus, setBackendStatus] = useState('checking');
  const [processes, setProcesses] = useState([]);
  const [forensic, setForensic] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedPid, setSelectedPid] = useState(null);
  const [processDetail, setProcessDetail] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    const checkBackend = () => {
      fetch(`${API_BASE}/health`)
        .then(r => {
          if (r.ok) {
            setBackendStatus('online');
            setRetryCount(0);
          } else {
            setBackendStatus('offline');
            setRetryCount(prev => prev + 1);
          }
        })
        .catch(() => {
          setBackendStatus('offline');
          setRetryCount(prev => prev + 1);
        });
    };
    checkBackend();
    const interval = setInterval(checkBackend, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchProcesses = () => {
    setLoading(true);
    fetch(`${API_BASE}/processes`)
      .then(r => r.json())
      .then(data => {
        setProcesses(data.processes || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  const runForensic = () => {
    setLoading(true);
    fetch(`${API_BASE}/forensic`)
      .then(r => r.json())
      .then(data => {
        setForensic(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  const fetchProcessDetail = (pid) => {
    setSelectedPid(pid);
    fetch(`${API_BASE}/process/${pid}`)
      .then(r => r.json())
      .then(data => setProcessDetail(data))
      .catch(() => setProcessDetail(null));
  };

  const projectPath = '/home/owner/Documents/6a9447c0-d534-83ea-b2c7-9ba48762a252/repo/fullstack-dashboard';
  const isGitHubPages = window.location.hostname.includes('github.io');

  return (
    <div className="App">
      <header className="App-header">
        <h1>🔬 System Resource Forensic Dashboard</h1>
        <p>Live system monitoring & forensic audit tools</p>

        <div className={`status-banner ${backendStatus}`}>
          {backendStatus === 'checking' && '⏳ Checking backend connection...'}
          {backendStatus === 'online' && (
            <>
              ✅ Backend is running – full functionality available
              <span className="status-dot online"></span>
            </>
          )}
          {backendStatus === 'offline' && (
            <>
              ⚠️ Backend not running – using limited/offline mode
              <span className="status-dot offline"></span>
              <div className="guidance">
                {isGitHubPages && (
                  <div className="github-pages-notice">
                    💡 You're viewing this on GitHub Pages
                    <br />
                    <small>For full functionality, run the backend locally.</small>
                  </div>
                )}
                <p>Start the backend with:</p>
                <code>cd {projectPath} && npm run dev:backend</code>
                {retryCount > 0 && (
                  <p className="retry-info">Connection attempts: {retryCount}</p>
                )}
                <p className="hint">Then refresh this page and click "Allow" if prompted.</p>
              </div>
            </>
          )}
        </div>

        <div className="controls">
          <button onClick={fetchProcesses} disabled={loading || backendStatus === 'offline'}>
            Refresh Processes
          </button>
          <button onClick={runForensic} disabled={loading || backendStatus === 'offline'}>
            Run Forensic Audit
          </button>
        </div>

        {backendStatus === 'offline' && (
          <div className="offline-notice">
            <p>💡 Some features are unavailable while the backend is offline.</p>
            <p>Start the backend using the command above to enable full functionality.</p>
          </div>
        )}

        {loading && <p>Loading...</p>}

        {forensic && (
          <div className="forensic-card">
            <h3>Forensic Report</h3>
            <pre>{forensic.top_processes}</pre>
            <h4>High CPU Processes (&gt;80%)</h4>
            <pre>{forensic.high_cpu_processes || 'None'}</pre>
            <h4>Asciinema Processes</h4>
            <pre>{forensic.asciinema_processes || 'None'}</pre>
            <h4>System Info</h4>
            <pre>Hostname: {forensic.system?.hostname}
Platform: {forensic.system?.platform}
Uptime: {forensic.system?.uptime}s
Memory: {Math.round(forensic.system?.freemem/1024/1024)}MB free / {Math.round(forensic.system?.totalmem/1024/1024)}MB total
CPUs: {forensic.system?.cpus}</pre>
          </div>
        )}

        {processes.length > 0 && (
          <div className="process-card">
            <h3>Process List (by CPU)</h3>
            <table>
              <thead><tr><th>PID</th><th>PPID</th><th>User</th><th>CPU%</th><th>MEM%</th><th>Time</th><th>Command</th><th>Detail</th></tr></thead>
              <tbody>
                {processes.slice(0, 30).map(p => (
                  <tr key={p.pid}>
                    <td>{p.pid}</td>
                    <td>{p.ppid}</td>
                    <td>{p.user}</td>
                    <td>{p.cpu}</td>
                    <td>{p.mem}</td>
                    <td>{p.etime}</td>
                    <td className="cmd">{p.cmd.slice(0, 40)}</td>
                    <td><button onClick={() => fetchProcessDetail(p.pid)}>🔍</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {processDetail && (
          <div className="detail-card">
            <h3>Process Detail: PID {selectedPid}</h3>
            <pre>{processDetail.status}</pre>
            <h4>I/O</h4>
            <pre>{processDetail.io}</pre>
            <h4>Command Line</h4>
            <pre>{processDetail.cmdline}</pre>
            <h4>Open FDs</h4>
            <pre>{processDetail.fds?.join('\n') || 'None'}</pre>
            <button onClick={() => setProcessDetail(null)}>Close</button>
          </div>
        )}

      </header>
    </div>
  );
}

export default App;
APP_JSX

# 2. Ensure CSS is correct
cat > frontend/src/App.css <<'APP_CSS'
.App {
  text-align: center;
  min-height: 100vh;
  background: #1e1e2f;
  color: #e0e0e0;
  font-family: 'Fira Code', 'Segoe UI', monospace;
  padding: 1rem;
}
.App-header {
  max-width: 1200px;
  margin: 0 auto;
}
h1 { font-size: 2.2rem; color: #00d4ff; }
h3 { color: #ffcc00; margin-top: 1.5rem; }

.status-banner {
  padding: 1rem 1.5rem;
  border-radius: 12px;
  margin: 1rem 0;
  font-weight: 500;
  text-align: left;
  border: 1px solid transparent;
}
.status-banner.checking {
  background: #2a2a3a;
  border-color: #888;
  color: #aaa;
}
.status-banner.online {
  background: #1a2a1a;
  border-color: #4caf50;
  color: #4caf50;
}
.status-banner.offline {
  background: #2a1a1a;
  border-color: #ff6b35;
  color: #ff6b35;
}
.status-dot {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-left: 10px;
}
.status-dot.online { background: #4caf50; }
.status-dot.offline { background: #ff6b35; }

.guidance {
  margin-top: 0.75rem;
  padding: 0.75rem;
  background: #0d0d1a;
  border-radius: 8px;
}
.guidance p {
  margin: 0.25rem 0;
  color: #e0e0e0;
}
.guidance code {
  display: block;
  background: #1a1a2a;
  padding: 0.5rem;
  border-radius: 4px;
  font-size: 0.85rem;
  color: #00d4ff;
  word-break: break-all;
}
.guidance .hint {
  font-size: 0.8rem;
  color: #888;
  margin-top: 0.5rem;
}
.guidance .retry-info {
  font-size: 0.8rem;
  color: #ffaa00;
  margin-top: 0.3rem;
}
.github-pages-notice {
  background: #1a1a2a;
  border-left: 3px solid #00d4ff;
  padding: 0.5rem 0.75rem;
  margin-bottom: 0.75rem;
  border-radius: 4px;
  font-size: 0.9rem;
  color: #aaa;
}
.offline-notice {
  background: #1a1a2a;
  border-left: 4px solid #ff6b35;
  padding: 0.75rem 1rem;
  margin: 0.5rem 0;
  border-radius: 4px;
  font-size: 0.9rem;
  color: #ccc;
}

.forensic-card, .process-card, .detail-card {
  background: #2a2a40;
  border-radius: 12px;
  padding: 1.5rem;
  margin: 1rem 0;
  text-align: left;
  overflow-x: auto;
}
.controls button {
  background: #3a3a5a;
  border: none;
  color: white;
  padding: 0.6rem 1.2rem;
  margin: 0.5rem;
  border-radius: 8px;
  cursor: pointer;
}
.controls button:hover { background: #4a4a7a; }
.controls button:disabled { opacity: 0.5; cursor: not-allowed; }
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
}
th, td {
  padding: 0.3rem 0.5rem;
  border-bottom: 1px solid #3a3a5a;
  text-align: left;
}
td.cmd { font-family: monospace; font-size: 0.8rem; }
pre {
  background: #0d0d1a;
  padding: 0.8rem;
  border-radius: 6px;
  overflow-x: auto;
  font-size: 0.8rem;
  white-space: pre-wrap;
}
.detail-card button {
  background: #ff4444;
  border: none;
  color: white;
  padding: 0.4rem 1rem;
  border-radius: 6px;
  margin-top: 1rem;
  cursor: pointer;
}
.detail-card button:hover { background: #cc0000; }
APP_CSS

# 3. Update GitHub Actions workflow with a timestamped cache key
echo "--- Updating workflow with fresh cache key ($TIMESTAMP) ---"
cat > .github/workflows/deploy.yml <<'DEPLOY_YML'
name: Deploy to GitHub Pages
on:
  push:
    branches: [ "main" ]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: "pages"
  cancel-in-progress: false
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: 'npm'
          cache-dependency-path: frontend/package-lock.json
      - name: Install and Build
        run: |
          cd frontend
          npm ci
          npm run build
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./frontend/dist
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
DEPLOY_YML

# 4. Commit and push
echo "--- Committing and pushing (timestamp: $TIMESTAMP) ---"
git add frontend/src/App.jsx frontend/src/App.css .github/workflows/deploy.yml
git commit -m "force: fresh build with timestamped cache key $TIMESTAMP"
git push origin main

# 5. Wait for deployment
echo "--- Waiting for GitHub Pages deployment ---"
MAX_ATTEMPTS=40
SLEEP=10
ATTEMPT=0
DEPLOYED=false
while [[ $ATTEMPT -lt $MAX_ATTEMPTS ]]; do
    ATTEMPT=$((ATTEMPT + 1))
    STATUS=$(gh api /repos/swipswaps/fullstack-dashboard/pages/builds/latest -q '.status' 2>/dev/null || echo "unknown")
    echo "Attempt $ATTEMPT: status=$STATUS"
    if [[ "$STATUS" == "built" ]]; then
        DEPLOYED=true
        echo "✅ Pages deployment successful."
        break
    fi
    sleep $SLEEP
done

# 6. Open with cache-busting query parameter
PAGES_URL="https://swipswaps.github.io/fullstack-dashboard/?t=$TIMESTAMP"
echo "--- Opening $PAGES_URL ---"
xdg-open "$PAGES_URL" 2>/dev/null || open "$PAGES_URL" 2>/dev/null || echo "Open $PAGES_URL manually"

echo
echo "==============================================================================="
echo "✅ Fresh build triggered with new cache key!"
echo "Visit: $PAGES_URL"
echo
echo "If you still see the old content, do a HARD REFRESH:"
echo "  - Chrome/Firefox: Ctrl+Shift+R (or Cmd+Shift+R on Mac)"
echo "  - Or open in an incognito/private window."
echo
echo "Make sure your backend is running:"
echo "  cd $PROJECT_DIR && npm run dev:backend"
echo "==============================================================================="
