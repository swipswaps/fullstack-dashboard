#!/usr/bin/env bash
#
# cache_bust_no_sed.sh
#
# Forces a new build of the frontend by appending a timestamp comment to App.jsx.
# This changes the file content, producing new asset hashes and bypassing the CDN cache.
#
# No sed is used – only echo >> to append a line.

set -u

# Find the project
PROJECT_DIR=""
for d in "$HOME/github/fullstack-dashboard" "$HOME/Documents/6a9447c0-d534-83ea-b2c7-9ba48762a252/repo/fullstack-dashboard" "./fullstack-dashboard" "../fullstack-dashboard"; do
    if [[ -d "$d" ]] && [[ -f "$d/package.json" ]]; then
        PROJECT_DIR="$d"
        break
    fi
done

if [[ -z "$PROJECT_DIR" ]]; then
    echo "ERROR: fullstack-dashboard not found."
    exit 1
fi

cd "$PROJECT_DIR" || exit 1
echo "--- Project found at: $(pwd) ---"

# Append a timestamp comment to force a new build hash
TIMESTAMP=$(date +%s)
echo "--- Adding cache-busting comment to App.jsx (timestamp: $TIMESTAMP) ---"
echo "// CACHE_BUST: $TIMESTAMP" >> frontend/src/App.jsx

# Commit and push
echo "--- Committing and pushing cache-bust ---"
git add frontend/src/App.jsx
git commit -m "ci: cache bust $TIMESTAMP"
git push origin main

# Wait for deployment
echo "--- Waiting for GitHub Pages deployment ---"
MAX_ATTEMPTS=40
SLEEP=10
ATTEMPT=0
DEPLOYED=false
while [[ $ATTEMPT -lt $MAX_ATTEMPTS ]]; do
    ATTEMPT=$((ATTEMPT + 1))
    STATUS=$(gh api /repos/swipswaps/fullstack-dashboard/pages/builds/latest -q '.status' 2>/dev/null || echo "unknown")
    echo "Attempt $ATTEMPT: status=$STATUS"
    if [[ "$STATUS" == "built" ]]; then
        DEPLOYED=true
        echo "✅ Pages deployment successful."
        break
    fi
    sleep $SLEEP
done

# Open with cache-busting query parameter
PAGES_URL="https://swipswaps.github.io/fullstack-dashboard/?t=$TIMESTAMP"
echo "--- Opening $PAGES_URL ---"
xdg-open "$PAGES_URL" 2>/dev/null || open "$PAGES_URL" 2>/dev/null || echo "Open $PAGES_URL manually"

echo
echo "==============================================================================="
echo "✅ Cache-bust deployed!"
echo "Visit: $PAGES_URL"
echo
echo "If you still see the old content, do a HARD REFRESH:"
echo "  - Chrome/Firefox: Ctrl+Shift+R (or Cmd+Shift+R on Mac)"
echo "  - Or open in an incognito/private window."
echo
echo "Make sure your backend is running:"
echo "  cd $PROJECT_DIR && npm run dev:backend"
echo "==============================================================================="
